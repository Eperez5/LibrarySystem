import java.time.LocalDate;
/**
 * Public class for the Library System
 * @author krist
 */
public class LibrarySystem {
    private String bookTitle;
    private LocalDate dueDate;
/**
 * Main constructor for the library system 
 * @param bookTitle Title of the book
 * @param dueDays Days the book is due
 */
    public LibrarySystem(String bookTitle, int dueDays) {
        this.bookTitle = bookTitle;
        this.dueDate = LocalDate.now().plusDays(dueDays);
    }
/**
 * Method that checks if the book is turned in on time and if it is not then there is a penalty but if it is then there is no penalty
 */
    public void checkIn() {
        LocalDate currentDate = LocalDate.now();

        if (currentDate.isAfter(dueDate)) {
            int daysLate = (int) dueDate.until(currentDate).getDays();
            double penalty = daysLate * 2.0;

            System.out.println("Book Title: " + bookTitle);
            System.out.println("Due Date: " + dueDate);
            System.out.println("Current Date: " + currentDate);
            System.out.println("Days Late: " + daysLate);
            System.out.println("Penalty: $" + penalty);
            System.out.println("Please pay the penalty at the front desk.");
        } else {
            System.out.println("Book Title: " + bookTitle);
            System.out.println("Due Date: " + dueDate);
            System.out.println("Current Date: " + currentDate);
            System.out.println("No penalty. Thank you for returning the book on time!");
        }
    }
/**
 * Method for checking out books and it will give a due date
 * @param dueDays 
 */
    public void checkOut(int dueDays) {
        dueDate = LocalDate.now().plusDays(dueDays);
        System.out.println("Book checked out. New due date: " + dueDate);
    }
}