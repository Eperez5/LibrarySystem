
        public class LibrarySystemTester {
    public static void main(String[] args) {
        // Test the LibrarySystem class
        LibrarySystem book1 = new LibrarySystem("Introduction to Java Programming", 14);
        LibrarySystem book2 = new LibrarySystem("Data Structures and Algorithms", 21);

        // Test check-in for book1
        System.out.println("Checking in book1:");
        book1.checkIn();

        // Test check-out for book1 with a new due date
        System.out.println("\nChecking out book1 with a new due date:");
        book1.checkOut(28);

        // Test check-in for book2
        System.out.println("\nChecking in book2:");
        book2.checkIn();

        // Test check-out for book2 with a new due date
        System.out.println("\nChecking out book2 with a new due date:");
        book2.checkOut(7);
    }
}







